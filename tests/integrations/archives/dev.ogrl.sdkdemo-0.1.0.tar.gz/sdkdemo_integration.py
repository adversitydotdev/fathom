"""SDK demo: an OGRL integration (RFC 0005)."""

from ogrl_integration import Integration, Subject, fail, pass_

app = Integration("dev.ogrl.sdkdemo", "0.1.0")


@app.validate
def validate(ctx):
    me = ctx.http.get(f"{ctx.config['base_url']}/me", headers=_auth(ctx)).json()
    return ctx.identity(f"{ctx.config['base_url']} as {me['name']}", scopes=me.get("scopes", []))


@app.resource("items", version=1)
def items(ctx):
    pages = ctx.http.paginate(
        f"{ctx.config['base_url']}/items",
        headers=_auth(ctx),
        items=lambda r: r.json()["items"],
        next_url=lambda r: r.json().get("next"),
    )
    for item in pages:
        yield {"id": item["id"], "name": item["name"], "enabled": item.get("enabled", False)}


@app.check("all-enabled", version=1)
def all_enabled(ctx, items):
    off = [i for i in items if not i.get("enabled")]
    if off:
        subjects = [Subject.resource(i["name"], i["id"]) for i in off]
        return fail(f"{len(off)} of {len(items)} items are disabled", subjects)
    return pass_(f"{len(items)} items are enabled")


def _auth(ctx):
    return {"Authorization": f"Bearer {ctx.secret('SDKDEMO_TOKEN')}"}
